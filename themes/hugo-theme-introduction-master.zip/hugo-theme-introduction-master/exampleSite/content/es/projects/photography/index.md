---
title: "Fotografía"
weight: 1
---

## A veces tomo fotografías

Este proyecto es sobre fotografías que tomo. A veces, son fotos de gatos.
