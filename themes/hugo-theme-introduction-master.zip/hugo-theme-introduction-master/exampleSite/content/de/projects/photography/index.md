---
title: "Fotografie"
weight: 1
---

## Machmal nehme ich Bilder auf

Dieses Projekt ist über die Bilder, die ich aufnehme. Machmal sind das Bilder von Katzen.
