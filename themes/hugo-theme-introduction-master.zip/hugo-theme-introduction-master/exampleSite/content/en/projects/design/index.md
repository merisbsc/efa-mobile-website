---
title: "Design"
weight: 2
resources:
    - src: plant.jpg
      params:
          weight: -100
project_timeframe: June-December
---

This theme was designed by [Victoria Drake](https://victoria.dev). Go on, explore! 💪

If you want to use it for your website, check out the section at the bottom of the main page. 👍
