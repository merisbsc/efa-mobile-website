---
title: "Contact"
---

In the Contact section of **Introduction**, you may optionally display the current time in your preferred timezone.

This lets visitors know what sort of response time to expect when they contact you. The timezone is easily set in the `config.toml` file. See the exampleSite configuration for instructions.
