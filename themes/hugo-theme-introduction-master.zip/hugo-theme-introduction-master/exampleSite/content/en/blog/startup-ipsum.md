---
title: "Startup Ipsum"
date: 2017-11-06T12:04:06-05:00
tags: ["code", "ipsum", "words"]
---

SpaceTeam affordances quantitative vs. qualitative SpaceTeam physical computing earned media thinker-maker-doer pair programming. Bootstrapping pitch deck physical computing driven cortado human-centered design innovate human-centered design driven. Grok pitch deck fund pitch deck sticky note affordances minimum viable product integrate paradigm viral iterate. Driven fund thought leader personas workflow SpaceTeam viral pair programming physical computing intuitive 360 campaign latte bootstrapping minimum viable product. Bootstrapping physical computing responsive pitch deck SpaceTeam parallax long shadow pitch deck bootstrapping ideate.

```sh
$ complicated techie code git bash ubuntu
>>> return value init foo
```

Responsive innovate grok latte disrupt intuitive actionable insight SpaceTeam grok. Human-centered design Steve Jobs Steve Jobs pitch deck pivot disrupt fund parallax affordances venture capital pair programming. Pivot earned media user centered design affordances agile innovate actionable insight latte.

| this | is | a   | table | !
|------|---:|-----|-------|---
| this | is | the | 1st   | row
| this | is | the | 2nd   | row
| this | is | the | 3rd   | row
| edgy | jo | ke  | lands | here
| this | is | the | 5th   | row
| this | is | the | 6th   | row

Waterfall is so 2000 and late personas pitch deck fund big data actionable insight unicorn driven grok. Engaging disrupt ship it big data waterfall is so 2000 and late iterate workflow food-truck pitch deck thought leader. Piverate user centered design unicorn pivot earned media ship it personas moleskine pivot co-working entrepreneur integrate. Affordances actionable insight ship it workflow integrate innovate integrate piverate pivot actionable insight innovate thought leader. Waterfall is so 2000 and late viral viral responsive Steve Jobs driven physical computing thinker-maker-doer piverate pivot.

- Unordered list
    - First sub-item
    - Second sub-item
- Second top level item

Now for an ordered list:

1. Top level
    1. First sub-level
        1. Second sub-level